document.write(
	'<a class="fixedbut" href="https://beauty.dikidi.net/#widget=23385">⋞ЗАПИС⋟</a>'
);
